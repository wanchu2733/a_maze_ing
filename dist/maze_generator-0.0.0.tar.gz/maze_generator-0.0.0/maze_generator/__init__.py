from maze_generator.maze_generator import *

