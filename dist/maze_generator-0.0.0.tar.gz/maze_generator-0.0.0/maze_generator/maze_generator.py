class MazeGenerator:
    a = 20
